package se.depi.model;

public enum Status {

	UNSTARTED, STARTED, DONE, UNACTIVE, ACTIVE
	
}
